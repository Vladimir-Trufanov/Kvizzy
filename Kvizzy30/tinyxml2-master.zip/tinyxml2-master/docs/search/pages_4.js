var searchData=
[
  ['file_0',['Load an XML File',['../_example_1.html',1,'']]],
  ['from_20char_20buffer_1',['Parse an XML from char buffer',['../_example_2.html',1,'']]]
];
