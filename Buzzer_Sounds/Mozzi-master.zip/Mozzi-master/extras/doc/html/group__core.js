var group__core =
[
    [ "MozziHeadersOnly.h", "_mozzi_headers_only_8h.html", null ],
    [ "Mozzi.h", "_mozzi_8h.html", null ],
    [ "twi_nonblock_HeadersOnly.h", "twi__nonblock___headers_only_8h.html", null ],
    [ "CONSTTABLE_STORAGE", "group__core.html#gad03d3ea20c802844460cd1ad636cf6a9", null ],
    [ "audioHook", "group__core.html#ga2fca37b988ab369e2f3c3108c683e59d", null ],
    [ "audioTicks", "group__core.html#ga55fa9d48f327b646c2f71cef7da7b8f0", null ],
    [ "FLASH_OR_RAM_READ", "group__core.html#ga14d8349004d9544dbd01b907c60c08aa", null ],
    [ "mozzi_pgm_read_wrapper", "group__core.html#ga6eab513d77c44e4a6e3cc63e95a35d98", null ],
    [ "mozziMicros", "group__core.html#gaaa6a42d80c5297407a45ca8bf3c1c7fe", null ],
    [ "stopMozzi", "group__core.html#ga8d9307490ec05ad28539d513c73a5c20", null ],
    [ "updateAudio", "group__core.html#ga936b78c8ab7a4d7f7075b41e32780d3e", null ],
    [ "updateControl", "group__core.html#ga59d187b915b2e366c88489e52801951a", null ]
];