var group__audio__output_mozzi_audio_output_architecture_dup =
[
    [ "Platform specific audio resolution", "group__audio__output.html#audio_shifting", [
      [ "Platform specific audio resolution", "group__audio__output.html#audio_shifting", null ]
    ] ]
];