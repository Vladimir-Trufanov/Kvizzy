var group__analog =
[
    [ "adcDisconnectAllDigitalIns", "group__analog.html#ga5042e7c576dd0307be38eb70efdb69fe", null ],
    [ "adcReconnectAllDigitalIns", "group__analog.html#gabad497d1f8c8026e81849be0b65bf38f", null ],
    [ "disconnectDigitalIn", "group__analog.html#ga532fe99fe78e34d4e6ae0ae2c7528353", null ],
    [ "getAudioInput", "group__analog.html#gacd5e655ae9057843ade0d7647f909663", null ],
    [ "getAudioInput16", "group__analog.html#gabb22bb94b66c6b2e583d745820cfac93", null ],
    [ "mozziAnalogRead", "group__analog.html#gadedb573129313bad0c183af2486c5283", null ],
    [ "mozziAnalogRead16", "group__analog.html#gaf869bc4f93cb0a90664a59b20fb4f556", null ],
    [ "reconnectDigitalIn", "group__analog.html#ga26462e443299e8d39a520d4a838e00b7", null ],
    [ "setupFastAnalogRead", "group__analog.html#gae909f8857d71ed79f277ee024de52574", null ]
];