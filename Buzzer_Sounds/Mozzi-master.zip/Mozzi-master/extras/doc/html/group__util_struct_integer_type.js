var group__util_struct_integer_type =
[
    [ "signed_type", "group__util.html#aaa3ae934adeb6283050b67466d9115fd", null ],
    [ "unsigned_type", "group__util.html#a3cbf76c03272c875c8e7b172060726ef", null ]
];