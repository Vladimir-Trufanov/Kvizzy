var group__config_config_main_dup =
[
    [ "Configuring Mozzi", "group__config.html#config_general", [
      [ "Configuring Mozzi", "group__config.html#config_general", null ]
    ] ]
];