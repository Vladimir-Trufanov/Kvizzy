var group__audio__output =
[
    [ "Basic architecture of audio generation, buffering, and output in Mozzi", "group__audio__output.html#mozzi_audio_output_architecture", "group__audio__output_mozzi_audio_output_architecture_dup" ],
    [ "External audio output", "group__audio__output.html#external_audio", null ]
];