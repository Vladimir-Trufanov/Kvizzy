var _mozzi_config_values_8h =
[
    [ "MOZZI_ANALOG_READ_NONE", "_mozzi_config_values_8h.html#a283cf3ec2e54d3bd0e83a9ad13c47196", null ],
    [ "MOZZI_ANALOG_READ_STANDARD", "_mozzi_config_values_8h.html#a84fc50e08fe6399aa79fcfc6d9b5a544", null ],
    [ "MOZZI_AUDIO_INPUT_NONE", "_mozzi_config_values_8h.html#aa0166eea48ec88e262126e89bba360f9", null ],
    [ "MOZZI_AUDIO_INPUT_STANDARD", "_mozzi_config_values_8h.html#a03787c9546c03c77fa5abdc51af2e8ea", null ],
    [ "MOZZI_COMPATIBILITY_1_1", "_mozzi_config_values_8h.html#a400056c9fc6d202d67ec42ae79fbc4c2", null ],
    [ "MOZZI_COMPATIBILITY_2_0", "_mozzi_config_values_8h.html#ae7cc4a1ce04d3aacbe968e8f920462e9", null ],
    [ "MOZZI_COMPATIBILITY_LATEST", "_mozzi_config_values_8h.html#a7bb35f3ef754aa2d2ae6d6b1a5356afa", null ],
    [ "MOZZI_I2S_FORMAT_LSBJ", "_mozzi_config_values_8h.html#ab71e0b01253f5d12a17bacdcd0d4bc98", null ],
    [ "MOZZI_I2S_FORMAT_PLAIN", "_mozzi_config_values_8h.html#aa6a3c50b0c4d8c057d8464cea20f493d", null ],
    [ "MOZZI_MONO", "_mozzi_config_values_8h.html#a9b71d48222658fcc7f7334135a5ea3b0", null ],
    [ "MOZZI_OUTPUT_2PIN_PWM", "_mozzi_config_values_8h.html#ad079ff2303024d89ac144dd8dd4880ae", null ],
    [ "MOZZI_OUTPUT_EXTERNAL_CUSTOM", "_mozzi_config_values_8h.html#ac568d605c859af89429417e5e7e52607", null ],
    [ "MOZZI_OUTPUT_EXTERNAL_TIMED", "_mozzi_config_values_8h.html#ae1a1bac4312daa42b2de8479c60bfc57", null ],
    [ "MOZZI_OUTPUT_I2S_DAC", "_mozzi_config_values_8h.html#a4c4808f0925b7b8e53cfe325989b8da4", null ],
    [ "MOZZI_OUTPUT_INTERNAL_DAC", "_mozzi_config_values_8h.html#ad9ae19449181ec345e3ca4797b4efb1e", null ],
    [ "MOZZI_OUTPUT_PDM_VIA_I2S", "_mozzi_config_values_8h.html#aa53f4f4b18e85fadf2b21767c520571b", null ],
    [ "MOZZI_OUTPUT_PDM_VIA_SERIAL", "_mozzi_config_values_8h.html#a5a46cd28abf78a0e314b7325fb2c17b8", null ],
    [ "MOZZI_OUTPUT_PWM", "_mozzi_config_values_8h.html#a3d19bcc872932c7b9fb663cbef8d9d5a", null ],
    [ "MOZZI_STEREO", "_mozzi_config_values_8h.html#ae7468340827c0cf521b19b0a6f352fea", null ]
];