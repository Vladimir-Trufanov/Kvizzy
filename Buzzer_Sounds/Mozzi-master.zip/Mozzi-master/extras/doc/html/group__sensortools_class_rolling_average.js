var group__sensortools_class_rolling_average =
[
    [ "RollingAverage", "group__sensortools.html#a11cf7b9e1278648b1eb10e5534fe3e29", null ],
    [ "add", "group__sensortools.html#a9c9f4083b726ed046c97a91535486317", null ],
    [ "next", "group__sensortools.html#a23c4b93258faace0c7ee60eb395d2c4b", null ]
];