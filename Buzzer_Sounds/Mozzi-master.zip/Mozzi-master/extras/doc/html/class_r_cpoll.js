var class_r_cpoll =
[
    [ "RCpoll", "class_r_cpoll.html#a44673505bbfbac288ec994dd48017e83", null ],
    [ "next", "class_r_cpoll.html#ab61697b3922ed289c8d501ccd11cbd6f", null ]
];