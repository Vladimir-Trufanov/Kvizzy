var searchData=
[
  ['trailingzerosconst_328',['trailingZerosConst',['../group__util.html#ga886894a381e3569d040262831ca9292a',1,'mozzi_utils.h']]],
  ['twi_5fnonblock_5fheadersonly_2eh_329',['twi_nonblock_HeadersOnly.h',['../twi__nonblock___headers_only_8h.html',1,'']]]
];
