var searchData=
[
  ['operator_20audiooutputstorage_5ft_134',['operator AudioOutputStorage_t',['../struct_mono_output.html#a1fa86997aa020097d6011b23ee35342a',1,'MonoOutput']]],
  ['operator_28_29_135',['operator()',['../group__sensortools.html#afd49885d3f05ca0a2f417199a9e7cf10',1,'AutoMap::operator()()'],['../class_int_map.html#ae3bf8b61f2ab79ac6626245213e7cb2a',1,'IntMap::operator()()'],['../class_smooth.html#a24eb02e4c4bfe9401f24ed0399b1e392',1,'Smooth::operator()()']]],
  ['oscil_136',['Oscil',['../class_oscil.html',1,'Oscil&lt; NUM_TABLE_CELLS, UPDATE_RATE &gt;'],['../class_oscil.html#afe6a75646d2dd822a654bcd85242e800',1,'Oscil::Oscil(const int8_t *TABLE_NAME)'],['../class_oscil.html#ab7dc5f97742d841fff6a4dca6d7242f3',1,'Oscil::Oscil()']]],
  ['oscil_3c_208192_2c_20mozzi_5faudio_5frate_20_3e_137',['Oscil&lt; 8192, MOZZI_AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20cos8192_5fnum_5fcells_2c_20mozzi_5faudio_5frate_20_3e_138',['Oscil&lt; COS8192_NUM_CELLS, MOZZI_AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20sin2048_5fnum_5fcells_2c_20mozzi_5faudio_5frate_20_3e_139',['Oscil&lt; SIN2048_NUM_CELLS, MOZZI_AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oversample_140',['OverSample',['../group__sensortools.html#class_over_sample',1,'']]]
];
