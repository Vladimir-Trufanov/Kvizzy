var searchData=
[
  ['getaudioinput_53',['getAudioInput',['../group__analog.html#gacd5e655ae9057843ade0d7647f909663',1,'MozziGuts.h']]],
  ['getaudioinput16_54',['getAudioInput16',['../group__analog.html#gabb22bb94b66c6b2e583d745820cfac93',1,'MozziGuts.h']]],
  ['getmax_55',['getMax',['../group__sensortools.html#a4d27e5fe43f9b376b537def88ac74119',1,'AutoRange']]],
  ['getmean_56',['getMean',['../group__sensortools.html#a8521a53cde7c5d28ac9c375aaee3a972',1,'RollingStat']]],
  ['getmin_57',['getMin',['../group__sensortools.html#acd1dae6e6ffb288efc1618e2453ad5ef',1,'AutoRange']]],
  ['getphasefractional_58',['getPhaseFractional',['../class_meta_oscil.html#a20f0dcb30669eee21bfaa237f038c35d',1,'MetaOscil::getPhaseFractional()'],['../class_oscil.html#aefafa92dd2065243a164c1d824f292d7',1,'Oscil::getPhaseFractional()']]],
  ['getrange_59',['getRange',['../group__sensortools.html#a75c842b27ad3917be6d29e3d35b485f3',1,'AutoRange']]],
  ['getstandarddeviation_60',['getStandardDeviation',['../group__sensortools.html#a234ab1d244e4b392056fcaa1fc1e4fc4',1,'RollingStat']]],
  ['getting_20started_61',['Getting Started',['../basic_info.html',1,'']]],
  ['getvariance_62',['getVariance',['../group__sensortools.html#a3e7e5f706e3b5ac2496f14b7b639775d',1,'RollingStat']]]
];
