var searchData=
[
  ['band_20',['band',['../class_multi_resonant_filter.html#a93c35829c63addc2f54f42ca3b30b37e',1,'MultiResonantFilter']]],
  ['basic_20architecture_20of_20audio_20generation_2c_20buffering_2c_20and_20output_20in_20mozzi_21',['Basic architecture of audio generation, buffering, and output in Mozzi',['../group__audio__output.html',1,'']]]
];
