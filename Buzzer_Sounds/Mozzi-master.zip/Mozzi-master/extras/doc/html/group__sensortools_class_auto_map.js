var group__sensortools_class_auto_map =
[
    [ "AutoMap", "group__sensortools.html#aec125f071bd83180ff0d0a71446725f3", null ],
    [ "getMax", "group__sensortools.html#a4d27e5fe43f9b376b537def88ac74119", null ],
    [ "getMin", "group__sensortools.html#acd1dae6e6ffb288efc1618e2453ad5ef", null ],
    [ "getRange", "group__sensortools.html#a75c842b27ad3917be6d29e3d35b485f3", null ],
    [ "next", "group__sensortools.html#a34bc821f4f662e54383dd9d61db782df", null ],
    [ "operator()", "group__sensortools.html#afd49885d3f05ca0a2f417199a9e7cf10", null ]
];