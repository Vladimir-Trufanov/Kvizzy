var mozzi__config__documentation_8h =
[
    [ "MOZZI_ANALOG_READ", "group__config.html#gac4c9e989df7beb3034cc26e571a41569", null ],
    [ "MOZZI_AUDIO_BITS", "group__config.html#ga68d4c7210dfdd68ea3eb418a1b7de0a2", null ],
    [ "MOZZI_AUDIO_BITS_PER_CHANNEL", "group__config.html#ga9bfd84013cbc04ddb51b31f583178720", null ],
    [ "MOZZI_AUDIO_CHANNELS", "group__config.html#ga6ffeecfb574900db4d3161ce0992b8bb", null ],
    [ "MOZZI_AUDIO_INPUT", "group__config.html#ga40857197e27e3b4d3ee7177e95f59d6d", null ],
    [ "MOZZI_AUDIO_INPUT_PIN", "group__config.html#gac448f990c61e43089f5aab5fdb80d4a6", null ],
    [ "MOZZI_AUDIO_MODE", "group__config.html#ga9b14b158a7a469612a89dcc9630933b7", null ],
    [ "MOZZI_AUDIO_PIN_1", "group__config.html#ga9b9905f3ee10d6446fa991e463cb63cf", null ],
    [ "MOZZI_AUDIO_RATE", "group__config.html#gabc7b46bc3dbe1078f411287572226eff", null ],
    [ "MOZZI_COMPATIBILITY_LEVEL", "group__config.html#ga9d4e8e86950fd08173ce6c16bcad0c76", null ],
    [ "MOZZI_CONTROL_RATE", "group__config.html#ga947e756a0229e73de0a32ff3ea542013", null ],
    [ "MOZZI_PWM_RATE", "group__config.html#ga3a6d77e502b179f2e490f6151e93414e", null ]
];