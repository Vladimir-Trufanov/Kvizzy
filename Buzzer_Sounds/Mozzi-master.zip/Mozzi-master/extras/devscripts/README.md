This folder holds scripts to help test changes to Mozzi and to build a deployable release and web page with freshly generated documentation.
Some may be a useful starting point for developers to automate parts of their own process.
The most useful script might be mozzi_compile_examples.sh which will compile and record all the Mozzi examples, so you can come back and listen to them to quickly find problems.
The Makefile is from https://github.com/sudar/Arduino-Makefile, but there are now lots to choose from for different platforms if you search Github.  
